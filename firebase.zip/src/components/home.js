import React, {Component} from 'react';
import {connect}  from 'react-redux';
import {Grid, Typography ,Button, Divider, Card ,CardContent, FormControl, InputLabel, Input, Select, MenuItem} from '@material-ui/core';
import NavBar from '../container/navBar';
import authAction from '../store/action/authAction';
import {Link} from 'react-router-dom';
import crimeAction from '../store/action/crimeAction';


class Home extends Component{
    constructor(props){
        super(props);

        this.state = {
            Drawer:false,
            city:'',
            report:'',
            reportList:["Crime Report", "Complain Report", "Missing Person"],
            search:[]
        }

        console.log(props)
    }

    toggleDrawer = open => {
        this.setState({ Drawer: open });
        if(this.props.user){
            console.log()
        }
      };
    
      componentDidMount(){
          if(this.props.user){
            const userId = this.props.user.uid
            this.props.getCrime(userId)
          }
          

          
          this.props.getComplain()
          this.props.getMissing()
      }
    
      changeHandler = eve =>{

        

        this.setState({[eve.target.name]: eve.target.value})

        

        if(eve.target.name === "report" && eve.target.value !== ''){
            console.log(eve.target.value)
           
        }
        else if(eve.target.name === "city" && eve.target.value !== ''){
            console.log(eve.target.value)
           
            
        }

        
    }

    searchHandler = (eve) => {


        const {report} = this.state;
        let search = {
            report:report,
            city:''
        }
        
        this.setState({[eve.target.name]: eve.target.value})

        if(eve.target.value !== '' && this.state.report !== ''){
            console.log('search', report, eve.target.value)
            search.city = eve.target.value

            
            console.log('search2', search)

            this.props.searchReport(search)
        }
    }

    render(){

        
       
     
        return(
            <div style={{flexGrow: 1}}>
              

                <NavBar openDrawer={this.state.Drawer} toggleDrawer={this.toggleDrawer} />

                <Grid container spacing={16} alignItems="center" direction="column" justify="center" >
                <Grid item xs={12} sm={12} style={{marginTop:20}}>
    
                <Button variant="contained" color="secondary"><Link to="/complains">View Complains</Link></Button>
                <Button variant="contained" color="secondary"><Link to="/crimes">View Crimes</Link></Button>
                <Button variant="contained" color="secondary"><Link to="/missingpersons">View Missing Person</Link></Button>
                </Grid>

                 <Divider style={{marginTop:20}}/>

             
 
                </Grid>
               
                <Grid container spacing={16} justify="center" >
                  <Grid item xs={12} sm={8} style={{marginTop:20}} >
                <Card>
                <CardContent>
                <Typography style={{float:'left'}} gutterBottom variant="headline" component="h2">
                    Complain Report
                </Typography>
                <Typography style={{float:'right'}} gutterBottom variant="headline" component="h2">
                    {this.props.complainList.length}
                </Typography>
                </CardContent>
                    </Card>

                    <Card>
                <CardContent>
                <Typography style={{float:'left'}} gutterBottom variant="headline" component="h2">
                    Crime Report
                </Typography>
                <Typography style={{float:'right'}} gutterBottom variant="headline" component="h2">
                {this.props.crimeList.length}
                </Typography>
                </CardContent>
                    </Card>

                    <Card>
                <CardContent>
                <Typography style={{float:'left'}} gutterBottom variant="headline" component="h2">
                    Missing Person
                </Typography>
                <Typography style={{float:'right'}} gutterBottom variant="headline" component="h2">
                {this.props.missingList.length}
                </Typography>
                </CardContent>
                    </Card>
                </Grid>
                </Grid>

            <Grid container spacing={16} direction="row" justify="center">
                
                <Grid item item xs={10} sm={5}>
                <FormControl fullWidth >
                    <InputLabel htmlFor="report">Search By Report</InputLabel>
                    <Select name="report" id="report"
                        value={this.state.report}
                        onChange={this.changeHandler}
                        inputProps={{
                        name: 'report',
                        id: 'report',
                        }}
                    >
                   
                   {
                        this.state.reportList.map(value => {
                        return <MenuItem value={value}>{value}</MenuItem>
                        })
                    
                    }
                        
                       
                    </Select>
                    </FormControl>
                </Grid>


                <Grid item xs={10} sm={5}>
                <FormControl fullWidth>
                    <InputLabel htmlFor="city">Which City</InputLabel>
                    <Select
                        value={this.state.city}
                        onChange={this.searchHandler}
                        inputProps={{
                        name: 'city',
                        id: 'city',
                        }}
                    >
                    {
                        this.props.city.map(value => {
                        return <MenuItem value={value}>{value}</MenuItem>
                        })
                    
                    }
                    
                    </Select>
                    </FormControl>
                </Grid>
            </Grid>

            </div>
        )
    }

   
}





const mapStateToProps = (state) => {
    return{
        city:state.crimeReducer.city,
        user:state.authReducer.user,
        isLoading:state.authReducer.isLoading,
        crimeList:state.crimeReducer.crimeList,
        missingList:state.crimeReducer.missingList,
        complainList:state.crimeReducer.complainList
    }
}

const mapDispatchToProps = (dispatch) => {
    return{
        logout:()=>{return dispatch(authAction.signOut())},
        getCrime: (userId)=>{return dispatch(crimeAction.getCrime(userId))},
        getMissing: ()=>{return dispatch(crimeAction.getMissing())},
        getComplain: ()=>{return dispatch(crimeAction.getComplain())},
        searchReport: (payload) => {return dispatch(crimeAction.searchReport(payload))}
    }
}


export default connect(mapStateToProps, mapDispatchToProps)(Home)