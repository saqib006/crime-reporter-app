Crime Reporter App  (React, redux, firebase)
admin: saqib@gmail.com // pass: saqib123

https://crime-reporter-react.firebaseapp.com/